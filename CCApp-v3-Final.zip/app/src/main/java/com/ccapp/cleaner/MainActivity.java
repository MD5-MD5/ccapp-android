package com.ccapp.cleaner;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static class AppEntry {
        String appName;
        String packageName;
        long cacheBytes;
        boolean selected;
        android.graphics.drawable.Drawable icon;
    }

    private final List<AppEntry> appList = new ArrayList<>();
    private AppListAdapter adapter;
    private TextView totalCacheText;
    private TextView subtitleStatusText;
    private Button usagePermBtn;
    private Button accessPermBtn;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0B0F19"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B0F19"));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionButtons();

        if (CleanerState.isAutoCleaning) {
            CleanerState.currentIndex++;
            if (CleanerState.currentIndex < CleanerState.packageQueue.size()) {
                handler.postDelayed(this::launchCurrentQueueApp, 350);
            } else {
                long freed = CleanerState.bytesFreedInSession;
                CleanerState.reset();
                Toast.makeText(this, "Turbo Clean Complete! Freed " + formatBytes(freed), Toast.LENGTH_LONG).show();
                scanInstalledApps();
            }
        } else {
            scanInstalledApps();
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B0F19"));
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("CCApp • Real Native Cleaner");
        title.setTextColor(Color.parseColor("#F1F5F9"));
        title.setTextSize(20f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button rescanBtn = createStyledButton("Rescan", "#1E2940", "#38BDF8");
        rescanBtn.setOnClickListener(v -> scanInstalledApps());
        header.addView(rescanBtn);
        root.addView(header);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(20), dp(22), dp(20), dp(22));
        GradientDrawable heroBg = new GradientDrawable();
        heroBg.setColor(Color.parseColor("#151C2C"));
        heroBg.setCornerRadius(dp(18));
        heroBg.setStroke(dp(1), Color.parseColor("#26334D"));
        hero.setBackground(heroBg);

        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        heroLp.topMargin = dp(14);
        heroLp.bottomMargin = dp(12);

        totalCacheText = new TextView(this);
        totalCacheText.setText("0 MB");
        totalCacheText.setTextColor(Color.parseColor("#00E5A3"));
        totalCacheText.setTextSize(34f);
        totalCacheText.setTypeface(Typeface.DEFAULT_BOLD);
        hero.addView(totalCacheText);

        subtitleStatusText = new TextView(this);
        subtitleStatusText.setText("Scanning installed apps...");
        subtitleStatusText.setTextColor(Color.parseColor("#94A3B8"));
        subtitleStatusText.setTextSize(13f);
        hero.addView(subtitleStatusText);

        Button cleanBtn = createStyledButton("⚡ TURBO CLEAN SELECTED APPS", "#00E5A3", "#05131D");
        LinearLayout.LayoutParams cleanLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cleanLp.topMargin = dp(16);
        cleanBtn.setOnClickListener(v -> startCleaningQueue());
        hero.addView(cleanBtn, cleanLp);

        root.addView(hero, heroLp);

        LinearLayout permRow = new LinearLayout(this);
        permRow.setOrientation(LinearLayout.HORIZONTAL);

        usagePermBtn = createStyledButton("1. Grant Usage Access", "#151C2C", "#F59E0B");
        LinearLayout.LayoutParams p1Lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p1Lp.rightMargin = dp(6);
        usagePermBtn.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        });

        accessPermBtn = createStyledButton("2. Enable Auto-Clicker", "#151C2C", "#38BDF8");
        LinearLayout.LayoutParams p2Lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p2Lp.leftMargin = dp(6);
        accessPermBtn.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        permRow.addView(usagePermBtn, p1Lp);
        permRow.addView(accessPermBtn, p2Lp);
        root.addView(permRow);

        ListView listView = new ListView(this);
        listView.setDividerHeight(dp(8));
        adapter = new AppListAdapter();
        listView.setAdapter(adapter);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        );
        listLp.topMargin = dp(12);
        root.addView(listView, listLp);

        setContentView(root);
    }

    private Button createStyledButton(String text, String bgHex, String fgHex) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor(fgHex));
        b.setTextSize(13f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.parseColor("#26334D"));
        b.setBackground(bg);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private void updatePermissionButtons() {
        boolean hasUsage = hasUsageStatsPermission();
        boolean hasAccess = isAccessibilityServiceEnabled();

        usagePermBtn.setText(hasUsage ? "✓ Usage Access Active" : "1. Grant Usage Access");
        usagePermBtn.setTextColor(Color.parseColor(hasUsage ? "#00E5A3" : "#F59E0B"));

        accessPermBtn.setText(hasAccess ? "✓ Auto-Clicker Active" : "2. Enable Auto-Clicker");
        accessPermBtn.setTextColor(Color.parseColor(hasAccess ? "#00E5A3" : "#38BDF8"));
    }

    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            getPackageName()
        );
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private boolean isAccessibilityServiceEnabled() {
        String serviceId = getPackageName() + "/" + CacheCleanerAccessibilityService.class.getCanonicalName();
        String enabled = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        return !TextUtils.isEmpty(enabled) && enabled.contains(serviceId);
    }

    private void scanInstalledApps() {
        subtitleStatusText.setText("Reading real app caches...");
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            StorageStatsManager statsManager = (StorageStatsManager) getSystemService(Context.STORAGE_STATS_SERVICE);
            UserHandle user = Process.myUserHandle();
            boolean hasUsage = hasUsageStatsPermission();

            List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<AppEntry> results = new ArrayList<>();

            for (ApplicationInfo info : installed) {
                if (info.packageName.equals(getPackageName())) continue;

                boolean isUserApp = (info.flags & ApplicationInfo.FLAG_SYSTEM) == 0
                    || (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (!isUserApp) continue;

                long cacheBytes = 0L;
                if (hasUsage && statsManager != null) {
                    try {
                        StorageStats stats = statsManager.queryStatsForPackage(
                            StorageManager.UUID_DEFAULT, info.packageName, user
                        );
                        cacheBytes = stats.getCacheBytes();
                    } catch (Exception ignored) {
                    }
                }

                if (hasUsage && cacheBytes < 64 * 1024) continue;

                AppEntry entry = new AppEntry();
                entry.appName = pm.getApplicationLabel(info).toString();
                entry.packageName = info.packageName;
                entry.cacheBytes = cacheBytes;
                entry.selected = cacheBytes > 1024 * 1024 || !hasUsage;
                entry.icon = pm.getApplicationIcon(info);
                results.add(entry);
            }

            Collections.sort(results, (a, b) -> Long.compare(b.cacheBytes, a.cacheBytes));

            handler.post(() -> {
                appList.clear();
                appList.addAll(results);
                adapter.notifyDataSetChanged();
                refreshSummary();
            });
        }).start();
    }

    private void refreshSummary() {
        long totalSelectedBytes = 0L;
        int selectedCount = 0;
        for (AppEntry e : appList) {
            if (e.selected) {
                totalSelectedBytes += e.cacheBytes;
                selectedCount++;
            }
        }
        totalCacheText.setText(formatBytes(totalSelectedBytes));
        if (!hasUsageStatsPermission()) {
            subtitleStatusText.setText("Tap '1. Grant Usage Access' below to read exact MB/GB cache sizes");
        } else {
            subtitleStatusText.setText(selectedCount + " apps selected • Ready to clean");
        }
    }

    private void startCleaningQueue() {
        CleanerState.reset();
        long plannedBytes = 0L;
        for (AppEntry e : appList) {
            if (e.selected) {
                CleanerState.packageQueue.add(e.packageName);
                plannedBytes += e.cacheBytes;
            }
        }

        if (CleanerState.packageQueue.isEmpty()) {
            Toast.makeText(this, "Select at least one app to clean!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(
                this,
                "Tip: Enable '2. Auto-Clicker' in Accessibility so CCApp taps Clear Cache automatically!",
                Toast.LENGTH_LONG
            ).show();
        }

        CleanerState.isAutoCleaning = true;
        CleanerState.currentIndex = 0;
        CleanerState.bytesFreedInSession = plannedBytes;
        launchCurrentQueueApp();
    }

    private void launchCurrentQueueApp() {
        if (CleanerState.currentIndex >= CleanerState.packageQueue.size()) {
            CleanerState.reset();
            return;
        }
        String pkg = CleanerState.packageQueue.get(CleanerState.currentIndex);
        CleanerState.storageEnteredForCurrentApp = false;
        CleanerState.cacheClickedForCurrentApp = false;
        CleanerState.lastActionTimestamp = 0L;

        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + pkg));
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 MB";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb >= 1024.0) {
            return String.format(Locale.US, "%.2f GB", mb / 1024.0);
        }
        return String.format(Locale.US, "%.1f MB", mb);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private class AppListAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return appList.size();
        }

        @Override
        public Object getItem(int position) {
            return appList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(12), dp(12), dp(12));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#151C2C"));
            bg.setCornerRadius(dp(14));
            bg.setStroke(dp(1), Color.parseColor("#26334D"));
            row.setBackground(bg);

            AppEntry item = appList.get(position);

            ImageView iconView = new ImageView(MainActivity.this);
            iconView.setImageDrawable(item.icon);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(42), dp(42));
            iconLp.rightMargin = dp(12);
            row.addView(iconView, iconLp);

            LinearLayout textCol = new LinearLayout(MainActivity.this);
            textCol.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams textColLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);

            TextView nameView = new TextView(MainActivity.this);
            nameView.setText(item.appName);
            nameView.setTextColor(Color.parseColor("#F1F5F9"));
            nameView.setTextSize(15f);
            nameView.setTypeface(Typeface.DEFAULT_BOLD);
            textCol.addView(nameView);

            TextView pkgView = new TextView(MainActivity.this);
            pkgView.setText(item.packageName);
            pkgView.setTextColor(Color.parseColor("#94A3B8"));
            pkgView.setTextSize(11f);
            textCol.addView(pkgView);

            row.addView(textCol, textColLp);

            TextView sizeView = new TextView(MainActivity.this);
            sizeView.setText(hasUsageStatsPermission() ? formatBytes(item.cacheBytes) : "Tap to Clean");
            sizeView.setTextColor(Color.parseColor("#F59E0B"));
            sizeView.setTextSize(13f);
            sizeView.setTypeface(Typeface.DEFAULT_BOLD);
            sizeView.setPadding(dp(8), 0, dp(10), 0);
            row.addView(sizeView);

            CheckBox checkBox = new CheckBox(MainActivity.this);
            checkBox.setChecked(item.selected);
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                item.selected = isChecked;
                refreshSummary();
            });
            row.addView(checkBox);

            return row;
        }
    }
}
