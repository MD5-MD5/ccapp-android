package com.ccapp.cleaner;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class CacheCleanerAccessibilityService extends AccessibilityService {

    public static CacheCleanerAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isPolling = false;

    private static final String[] CLEAR_CACHE_LABELS = {"clear cache", "wipe cache"};
    private static final String[] STORAGE_MENU_LABELS = {"storage & cache", "storage and cache", "storage usage", "storage"};

    // A foolproof fallback poller to check the screen if Android drops an event
    private final Runnable fallbackPoller = new Runnable() {
        @Override
        public void run() {
            if (CleanerState.isAutoCleaning) {
                processCurrentScreen();
                handler.postDelayed(this, 800);
            } else {
                isPolling = false;
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!CleanerState.isAutoCleaning) return;
        
        // Start the poller the first time an event fires during a cleaning session
        if (!isPolling) {
            isPolling = true;
            handler.post(fallbackPoller);
        }
        
        processCurrentScreen();
    }

    private void processCurrentScreen() {
        if (!CleanerState.isAutoCleaning) return;

        long now = System.currentTimeMillis();
        // Prevent rapid double-clicking, but allow the poller to retry automatically
        if (now - CleanerState.lastActionTimestamp < 700) {
            return; 
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        CharSequence pkgChar = root.getPackageName();
        if (pkgChar == null) return;
        String pkg = pkgChar.toString().toLowerCase();

        if (!pkg.contains("settings") && !pkg.contains("miui") && !pkg.contains("coloros")) {
            return;
        }

        // Step 1: Look for "Clear Cache" screen first
        if (!CleanerState.cacheClickedForCurrentApp) {
            AccessibilityNodeInfo clearBtn = findClickableNodeByLabels(root, CLEAR_CACHE_LABELS);
            if (clearBtn != null) {
                CleanerState.lastActionTimestamp = now;
                CleanerState.cacheClickedForCurrentApp = true;
                
                if (clearBtn.isEnabled()) {
                    clearBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                }
                
                handler.postDelayed(() -> {
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    handler.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_BACK), 400);
                }, 500);
                return;
            }
        }

        // Step 2: If not on Clear Cache screen, look for "Storage & cache"
        if (!CleanerState.storageEnteredForCurrentApp) {
            AccessibilityNodeInfo storageRow = findClickableNodeByLabels(root, STORAGE_MENU_LABELS);
            if (storageRow != null) {
                CleanerState.lastActionTimestamp = now;
                CleanerState.storageEnteredForCurrentApp = true;
                storageRow.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
        }
    }

    private AccessibilityNodeInfo findClickableNodeByLabels(AccessibilityNodeInfo root, String[] labels) {
        for (String label : labels) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(label);
            if (nodes != null) {
                for (AccessibilityNodeInfo node : nodes) {
                    CharSequence text = node.getText();
                    CharSequence desc = node.getContentDescription();
                    String t = text != null ? text.toString().toLowerCase().trim() : "";
                    String d = desc != null ? desc.toString().toLowerCase().trim() : "";
                    String l = label.toLowerCase();
                    
                    if (t.contains(l) || d.contains(l)) {
                        AccessibilityNodeInfo clickable = getClickableParent(node);
                        if (clickable != null) return clickable;
                    }
                }
            }
        }
        return null;
    }

    private AccessibilityNodeInfo getClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        int depth = 0;
        while (current != null && depth < 6) {
            if (current.isClickable()) return current;
            current = current.getParent();
            depth++;
        }
        return null;
    }

    @Override
    public void onInterrupt() {
        CleanerState.reset();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }
}
