package com.ccapp.cleaner;

import java.util.ArrayList;
import java.util.List;

public class CleanerState {
    public static volatile boolean isAutoCleaning = false;
    public static volatile boolean storageEnteredForCurrentApp = false;
    public static volatile boolean cacheClickedForCurrentApp = false;
    public static volatile long lastActionTimestamp = 0L;
    public static final List<String> packageQueue = new ArrayList<>();
    public static volatile int currentIndex = 0;
    public static volatile long bytesFreedInSession = 0L;

    public static synchronized void reset() {
        isAutoCleaning = false;
        storageEnteredForCurrentApp = false;
        cacheClickedForCurrentApp = false;
        packageQueue.clear();
        currentIndex = 0;
    }
}
