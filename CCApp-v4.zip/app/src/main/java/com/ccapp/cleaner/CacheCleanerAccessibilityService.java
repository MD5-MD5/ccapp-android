package com.ccapp.cleaner;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CacheCleanerAccessibilityService extends AccessibilityService {

    public static volatile CacheCleanerAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isPolling = false;
    private boolean isTransitioningApp = false;

    // Live Accessibility Overlay UI (prevents Android 17 from killing/disabling the service)
    private WindowManager windowManager;
    private LinearLayout overlayView;
    private TextView overlayStatusText;

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            try {
                if (CleanerState.isAutoCleaning) {
                    showOrUpdateOverlay();
                    processCurrentScreen();
                    handler.postDelayed(this, 750);
                } else {
                    hideOverlay();
                    isPolling = false;
                }
            } catch (Throwable ignored) {
                if (CleanerState.isAutoCleaning) {
                    handler.postDelayed(this, 750);
                }
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        } catch (Throwable ignored) {
        }
    }

    public void startQueueFromService() {
        try {
            isTransitioningApp = false;
            showOrUpdateOverlay();
            if (!isPolling) {
                isPolling = true;
                handler.removeCallbacks(poller);
                handler.postDelayed(poller, 500);
            }
            launchCurrentAppSettings();
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            if (!CleanerState.isAutoCleaning) return;
            if (!isPolling) {
                isPolling = true;
                handler.removeCallbacks(poller);
                handler.post(poller);
            }
        } catch (Throwable ignored) {
        }
    }

    private void processCurrentScreen() {
        if (!CleanerState.isAutoCleaning || isTransitioningApp) return;

        long now = System.currentTimeMillis();
        if (now - CleanerState.lastActionTimestamp < 600) {
            return;
        }

        AccessibilityNodeInfo root = getActiveRootNode();
        if (root == null) return;

        CharSequence pkgChar = root.getPackageName();
        String pkg = pkgChar != null ? pkgChar.toString().toLowerCase() : "";

        // Ignore our own app window
        if (pkg.equals(getPackageName().toLowerCase())) {
            return;
        }

        CleanerState.totalTicksOnCurrentApp++;
        // Safety timeout: if stuck on an app for more than 12 ticks (~9 seconds), move to next app
        if (CleanerState.totalTicksOnCurrentApp > 12) {
            updateOverlayText("Skipping unresponsive screen...");
            advanceToNextApp();
            return;
        }

        List<AccessibilityNodeInfo> allNodes = new ArrayList<>();
        collectAllNodes(root, allNodes);

        // STEP 1: Check if "Clear cache" is visible on screen (meaning we are inside Storage & cache)
        AccessibilityNodeInfo clearCacheNode = findClearCacheNode(allNodes);
        if (clearCacheNode != null) {
            CleanerState.lastActionTimestamp = now;
            CleanerState.cacheClickedForCurrentApp = true;

            if (isNodeOrParentEnabled(clearCacheNode)) {
                updateOverlayText(getProgressPrefix() + "Tapping Clear cache...");
                boolean clicked = performSmartClick(clearCacheNode, true);
                if (!clicked) {
                    tapNodeCoordinates(clearCacheNode);
                }
            } else {
                updateOverlayText(getProgressPrefix() + "Cache already 0 B...");
            }

            isTransitioningApp = true;
            handler.postDelayed(this::advanceToNextApp, 750);
            return;
        }

        // STEP 2: We are on the App Info screen -> Find "Storage & cache"
        AccessibilityNodeInfo storageNode = findStorageRowNode(allNodes);
        if (storageNode != null) {
            CleanerState.lastActionTimestamp = now;
            CleanerState.storageClickAttempts++;
            updateOverlayText(getProgressPrefix() + "Opening Storage & cache...");

            // On attempt 1, try standard accessibility click; if it fails or on attempt 2+, also tap screen coordinates
            boolean useGesture = CleanerState.storageClickAttempts >= 2;
            boolean clicked = performSmartClick(storageNode, useGesture);
            if (!clicked || useGesture) {
                tapNodeCoordinates(storageNode);
            }
        }
    }

    private void advanceToNextApp() {
        try {
            if (!CleanerState.isAutoCleaning) return;

            // Back out of the current Settings sub-screen first
            performGlobalAction(GLOBAL_ACTION_BACK);

            CleanerState.currentIndex++;
            if (CleanerState.currentIndex < CleanerState.packageQueue.size()) {
                handler.postDelayed(() -> {
                    isTransitioningApp = false;
                    launchCurrentAppSettings();
                }, 450);
            } else {
                // Entire queue finished!
                CleanerState.isAutoCleaning = false;
                CleanerState.sessionCompletedToastPending = true;
                isTransitioningApp = false;
                hideOverlay();
                handler.postDelayed(this::returnToCCAppHome, 350);
            }
        } catch (Throwable ignored) {
        }
    }

    private void launchCurrentAppSettings() {
        try {
            if (CleanerState.currentIndex >= CleanerState.packageQueue.size()) {
                CleanerState.reset();
                hideOverlay();
                return;
            }
            String targetPkg = CleanerState.packageQueue.get(CleanerState.currentIndex);
            CleanerState.cacheClickedForCurrentApp = false;
            CleanerState.storageClickAttempts = 0;
            CleanerState.totalTicksOnCurrentApp = 0;
            CleanerState.lastActionTimestamp = System.currentTimeMillis();

            updateOverlayText(getProgressPrefix() + "Opening App Info...");

            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + targetPkg));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Throwable ignored) {
            advanceToNextApp();
        }
    }

    private void returnToCCAppHome() {
        try {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Throwable ignored) {
        }
    }

    private String getProgressPrefix() {
        int idx = CleanerState.currentIndex + 1;
        int total = CleanerState.packageQueue.size();
        String name = (CleanerState.currentIndex < CleanerState.appNameQueue.size())
            ? CleanerState.appNameQueue.get(CleanerState.currentIndex)
            : "App";
        return "(" + idx + "/" + total + ") " + name + ": ";
    }

    private AccessibilityNodeInfo getActiveRootNode() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) return root;

            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo window : windows) {
                    if (window.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        AccessibilityNodeInfo r = window.getRoot();
                        if (r != null) return r;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void collectAllNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null || out.size() > 450) return;
        out.add(node);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) {
            try {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) {
                    collectAllNodes(child, out);
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private AccessibilityNodeInfo findClearCacheNode(List<AccessibilityNodeInfo> nodes) {
        for (AccessibilityNodeInfo node : nodes) {
            String t = getNodeTextLower(node);
            if (t.isEmpty()) continue;
            // Must never match "clear storage" or "clear data"
            if (t.contains("clear storage") || t.contains("clear data") || t.contains("manage space")) {
                continue;
            }
            if (t.contains("clear cache") || t.contains("wipe cache")) {
                return node;
            }
        }
        return null;
    }

    private AccessibilityNodeInfo findStorageRowNode(List<AccessibilityNodeInfo> nodes) {
        // Pass 1: Look specifically for "storage & cache" or "storage and cache" or "storage usage"
        for (AccessibilityNodeInfo node : nodes) {
            String t = getNodeTextLower(node);
            if (t.isEmpty()) continue;
            if (t.contains("storage & cache") || t.contains("storage and cache") || t.contains("storage usage")) {
                return node;
            }
        }
        // Pass 2: Look for exact title "storage" (avoiding "internal storage" subtitle if possible)
        for (AccessibilityNodeInfo node : nodes) {
            String t = getNodeTextLower(node);
            if (t.equals("storage")) {
                return node;
            }
        }
        return null;
    }

    private String getNodeTextLower(AccessibilityNodeInfo node) {
        try {
            StringBuilder sb = new StringBuilder();
            if (node.getText() != null) {
                sb.append(node.getText().toString().trim()).append(" ");
            }
            if (node.getContentDescription() != null) {
                sb.append(node.getContentDescription().toString().trim());
            }
            return sb.toString().toLowerCase().trim();
        } catch (Throwable ignored) {
            return "";
        }
    }

    private boolean isNodeOrParentEnabled(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo curr = node;
        int depth = 0;
        while (curr != null && depth < 5) {
            if (!curr.isEnabled()) return false;
            curr = curr.getParent();
            depth++;
        }
        return true;
    }

    private boolean performSmartClick(AccessibilityNodeInfo node, boolean alsoDispatchGesture) {
        boolean clicked = false;
        try {
            AccessibilityNodeInfo current = node;
            int depth = 0;
            while (current != null && depth < 6) {
                if (current.isClickable() && current.isEnabled()) {
                    clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if (clicked) break;
                }
                current = current.getParent();
                depth++;
            }
            if (!clicked && node.isEnabled()) {
                clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            if (alsoDispatchGesture) {
                tapNodeCoordinates(node);
            }
        } catch (Throwable ignored) {
        }
        return clicked;
    }

    private void tapNodeCoordinates(AccessibilityNodeInfo node) {
        try {
            Rect rect = new Rect();
            node.getBoundsInScreen(rect);
            if (rect.width() <= 0 || rect.height() <= 0) return;

            float cx = rect.exactCenterX();
            float cy = rect.exactCenterY();
            if (cx <= 0 || cy <= 0) return;

            Path path = new Path();
            path.moveTo(cx, cy);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 65);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);
            dispatchGesture(builder.build(), null, null);
        } catch (Throwable ignored) {
        }
    }

    private void showOrUpdateOverlay() {
        try {
            if (windowManager == null) {
                windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            }
            if (overlayView != null) return;

            overlayView = new LinearLayout(this);
            overlayView.setOrientation(LinearLayout.HORIZONTAL);
            overlayView.setGravity(Gravity.CENTER_VERTICAL);
            int padH = dp(14);
            int padV = dp(8);
            overlayView.setPadding(padH, padV, padH, padV);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#EE151C2C"));
            bg.setCornerRadius(dp(24));
            bg.setStroke(dp(1), Color.parseColor("#00E5A3"));
            overlayView.setBackground(bg);

            overlayStatusText = new TextView(this);
            overlayStatusText.setText("⚡ CCApp Auto-Cleaner Active...");
            overlayStatusText.setTextColor(Color.parseColor("#F1F5F9"));
            overlayStatusText.setTextSize(12f);
            overlayStatusText.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            );
            textLp.rightMargin = dp(10);
            overlayView.addView(overlayStatusText, textLp);

            Button stopBtn = new Button(this);
            stopBtn.setText("STOP");
            stopBtn.setTextSize(11f);
            stopBtn.setTextColor(Color.parseColor("#05131D"));
            stopBtn.setTypeface(Typeface.DEFAULT_BOLD);
            GradientDrawable stopBg = new GradientDrawable();
            stopBg.setColor(Color.parseColor("#F43F5E"));
            stopBg.setCornerRadius(dp(14));
            stopBtn.setBackground(stopBg);
            stopBtn.setPadding(dp(10), dp(4), dp(10), dp(4));
            stopBtn.setOnClickListener(v -> {
                CleanerState.reset();
                hideOverlay();
                returnToCCAppHome();
            });
            overlayView.addView(stopBtn);

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.y = dp(42);
            params.width = getResources().getDisplayMetrics().widthPixels - dp(32);

            windowManager.addView(overlayView, params);
        } catch (Throwable ignored) {
        }
    }

    private void updateOverlayText(String text) {
        handler.post(() -> {
            try {
                if (overlayStatusText != null) {
                    overlayStatusText.setText("⚡ " + text);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    private void hideOverlay() {
        handler.post(() -> {
            try {
                if (windowManager != null && overlayView != null) {
                    windowManager.removeView(overlayView);
                    overlayView = null;
                    overlayStatusText = null;
                }
            } catch (Throwable ignored) {
                overlayView = null;
                overlayStatusText = null;
            }
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onInterrupt() {
        CleanerState.reset();
        hideOverlay();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        CleanerState.reset();
        hideOverlay();
        instance = null;
        return super.onUnbind(intent);
    }
}
