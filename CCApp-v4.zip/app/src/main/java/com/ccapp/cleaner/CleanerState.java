package com.ccapp.cleaner;

import java.util.ArrayList;
import java.util.List;

public class CleanerState {
    public static volatile boolean isAutoCleaning = false;
    public static volatile boolean cacheClickedForCurrentApp = false;
    public static volatile int storageClickAttempts = 0;
    public static volatile int totalTicksOnCurrentApp = 0;
    public static volatile long lastActionTimestamp = 0L;
    public static final List<String> packageQueue = new ArrayList<>();
    public static final List<String> appNameQueue = new ArrayList<>();
    public static volatile int currentIndex = 0;
    public static volatile long bytesFreedInSession = 0L;
    public static volatile boolean sessionCompletedToastPending = false;

    public static synchronized void reset() {
        isAutoCleaning = false;
        cacheClickedForCurrentApp = false;
        storageClickAttempts = 0;
        totalTicksOnCurrentApp = 0;
        packageQueue.clear();
        appNameQueue.clear();
        currentIndex = 0;
    }
}
