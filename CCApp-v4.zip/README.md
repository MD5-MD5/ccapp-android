# CCApp - Real Native Android Cache Cleaner (APK Cloud Builder)

This project builds a real native Android `.apk` (**CCApp**) that works just like **Zero Cleaner**:
1. Uses Android's `StorageStatsManager` (`PACKAGE_USAGE_STATS`) to read **real cache sizes (MB/GB)** for installed apps on your phone.
2. Uses Android's `AccessibilityService` to automatically open each selected app's System Settings page, tap **Storage & cache**, tap **Clear cache**, and return to CCApp.

## How to Generate Your `CCApp.apk` for Free in 2 Minutes (No PC or Coding Software Needed)
1. Create a free account at [github.com](https://github.com) and create a **New Repository** (name it `ccapp-android`).
2. Upload the extracted files (or upload `CCApp-android-apk-builder.zip` directly and add `.github/workflows/build-apk.yml`).
3. Click the **Actions** tab at the top of your GitHub repository.
4. Wait ~90 seconds for **Build CCApp Android APK** to show a green checkmark ✅.
5. Scroll down to **Artifacts** on that workflow run and tap **`CCApp-Android-APK`** to download your ready-to-install `app-debug.apk`!
